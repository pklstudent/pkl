
<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
                            <?php if(session('sukses')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(session('sukses')); ?>

                                </div>
                            <?php endif; ?>
                <div class="row">
                <div class="col-md-12">
			<!-- TABLE HOVER -->
			<div class="panel">
				    <div class="panel-heading">
                        <h3 class="panel-title">Data PKL dan KKM</h3>
                        <div class="right">
                        <?php if(Auth::check() && Auth::user()): ?>
                        <button type="button" class="btn"><a href="/pklkkm/createpklkkm" class="btn btn-success">Tambah Data PKL atau KKm</a></button>
                        <?php endif; ?>
                        </div>  
                    </div> 
				<div class="panel-body">
					<table class="table table-hover">
						<thead>
							<tr>
                            <th>No</th>
                            <th>Judul</th>
                            <th>Tahun</th>
                            <th>File</th>
                            <th>Pembimbing</th>
                            <th>Mahasiswa</th>
                            <th>Mitra</th>
                            </tr>
						</thead>
						<tbody>
                        
                        <?php $__currentLoopData = $data_pklkkm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pklkkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($pklkkm->id); ?></td>
                            <td><?php echo e($pklkkm->Judul); ?></td>
                            <td><?php echo e($pklkkm->Tahun); ?></td>
                            <td><?php echo e($pklkkm->File); ?></td>
                            <td><?php echo e($pklkkm->Dosen['Nama']); ?></td>
                            <td><?php $__currentLoopData = $pklkkm->mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul><li><?php echo e($per->Nama); ?></li></ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                            <td><?php echo e($pklkkm->Mitra['Nama']); ?></td>
                            <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                            <td><a href="/pklkkm/<?php echo e($pklkkm->id); ?>/editpklkkm" class="btn btn-warning btn-sm" >Ubah</a></td>
                            <td><a href="/pklkkm/<?php echo e($pklkkm->id); ?>/hapus" class="btn btn-danger btn-sm" onclick="return confirm('Hapus nih ?')">Hapus</a></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
					</table>
                    </table>
                    <b>Halaman :</b>                   <span class="badge"><?php echo e($data_pklkkm->currentPage()); ?></span><br/>
                    <b> Jumlah Data :</b>              <span class="badge"> <?php echo e($data_pklkkm->total()); ?> </span><br/>
                    <b> Data Per Halaman : </b>         <span class="badge">  <?php echo e($data_pklkkm->perPage()); ?></span> <br/>
                
                
                    <?php echo e($data_pklkkm->links()); ?>

				</div>
			</div>
			<!-- END TABLE HOVER -->

		</div>

                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Inputkan Datanya</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                            <form action="/pklkkm/create" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Kode PKL dan KKM</label>
                                <input name="id" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Silahkan jika ingin dikosongi">
                                <small id="emailHelp" class="form-text text-muted">Masukan Kode Pkl dan KKM</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="exampleInputEmail1">Judul</label>
                                <input name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Judul">
                                <small id="emailHelp" class="form-text text-muted">Masukan Judulnya</small>
                            </div>

                            <div class="form-group">
							<label for="pklkkm">Pembimbing</label>
								<select class="form-control" id="pklkkm" name="KodeDosen">
								<?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($ce->id); ?>"><?php echo e($ce->Nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            <div class="form-group">
                                        <label for="exampleInputEmail1">Anggota Mahasiswa</label>
                                        <div class="dropdown">
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Pilih Anggotanya<b class="caret"></b></button></a>
                                            <ul class="dropdown-menu">
                                            <div style="OVERFLOW-Y:scroll; WIDTH:300px; HEIGHT:300px">
                                            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <?php echo e(Form::checkbox('mahasiswa[]', $j->id)); ?>

                                                        <label value="<?php echo e($j->id); ?>">
                                                        <span><?php echo e($j->Nama); ?></span>
                                                        </label>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            </ul>
                                        </div>
                                        <small id="emailHelp" class="form-text text-muted">Pilih Anggota</small><br>
                                        <a class="btn btn-sm" href="/mahasiswa">Input Mahasiswa</a>
                            </div>
       
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tahun</label>
                                <input name="Tahun" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Tahun">
                                <small id="emailHelp" class="form-text text-muted">Masukan Tahun</small>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Laporan</label>
                                <input name="Laporan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Laporan">
                                <small id="emailHelp" class="form-text text-muted">Masukan Laporan</small>
                            </div>

                            <div class="form-group">
							<label for="pklkkm">Mitra</label>
								<select class="form-control" id="pklkkm" name="IDMitra">
								<?php $__currentLoopData = $mitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($cer->id); ?>"><?php echo e($cer->Nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                                <small id="emailHelp" class="form-text text-muted">Pilih Mitra</small>
                                <br><a class="btn btn-sm" href="/mitra">Input Mitra</a>
                            </div>
                            
                            
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Sikat</button>
                        </form>
                    </div>
                    </div>
                </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/perpustakaan/resources/views/pklkkm/index.blade.php ENDPATH**/ ?>