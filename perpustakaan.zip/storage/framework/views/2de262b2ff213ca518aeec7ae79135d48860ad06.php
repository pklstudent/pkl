<?php $__env->startSection('content'); ?>
    <div class="main-content" >
      <div class="container-fluid">
        <div class="panel">       
              <div class="row">
              <div class="panel-heading">
                <h3 class="panel-title"><b>Beranda</b></h2>
                  <div class="right">
                    <button type="button" data-toggle="modal" data-target="#rolemahasiswaModal"><a  class="btn btn-default btn-sm" ><i class="fa fa-plus-square"></i>Registrasi Mahasiswa</a></button>
                    <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                    <button type="button" data-toggle="modal" data-target="#exampleModal"><a  class="btn btn-default btn-sm" ><i class="fa fa-plus-square"></i>Registrasi Admin</a></button>
                    <?php endif; ?>
                  </div>
              </div>
 
             <!--*****(thumbnail dashboard)*****-->
                    <div class="container-fluid p-0">
                      <!-- Adding Custom Content-->
                      <div class="col-lg-4 col-sm-6">
                        <div class="thumbnail">
                          <img src="<?php echo e(asset('public/admin/assets/img/1.jpg')); ?>" alt="buku">
                        </div>
                        <div class="caption">
                          <a href="<?php echo e(url('buku')); ?>" class="btn btn-primary btn-lg btn-block" role="button">BUKU</a>
                        </div>
                      </div>

                      <div class="col-lg-4 col-sm-6">
                        <div class="thumbnail">
                          <img src="<?php echo e(asset('public/admin/assets/img/2.jpg')); ?>" alt="skripsi">
                        </div>
                        <div class="caption">
                          <a href="<?php echo e(url('skripsi')); ?>" class="btn btn-primary btn-lg btn-block" role="button">SKRIPSI</a>
                        </div>
                      </div>

                      <div class="col-lg-4 col-sm-6">
                        <div class="thumbnail">
                          <img src="<?php echo e(asset('public/admin/assets/img/3.jpg')); ?>" alt="penelitian">
                        </div>
                        <div class="caption">
                          <a href="<?php echo e(url('penelitian')); ?>" class="btn btn-primary btn-lg btn-block" role="button">PENELITIAN</a>
                        </div>
                      </div>
                      <br/>

                      <div class="col-lg-4 col-sm-6">
                        <div class="thumbnail">
                          <img src="<?php echo e(asset('public/admin/assets/img/4.jpg')); ?>" alt="pengabdian">
                        </div>
                        <div class="caption">
                          <a href="<?php echo e(url('pengabdian')); ?>" class="btn btn-primary btn-lg btn-block" role="button">PENGABDIAN</a>
                        </div>
                      </div>

                      <div class="col-lg-4 col-sm-6">
                        <div class="thumbnail">
                          <img src="<?php echo e(asset('public/admin/assets/img/5.jpg')); ?>" alt="pkl/kkm">
                        </div>
                        <div class="caption">
                          <a href="<?php echo e(url('pklkkm')); ?>" class="btn btn-primary btn-lg btn-block" role="button">PKL/KKM</a>
                        </div>
                      </div>

                      <div class="col-lg-4 col-sm-6">
                        <div class="thumbnail">
                          <img src="<?php echo e(asset('public/admin/assets/img/6.jpg')); ?>" alt="publikasi">
                        </div>
                        <div class="caption">
                          <a href="<?php echo e(url('publikasi')); ?>" class="btn btn-primary btn-lg btn-block" role="button">PUBLIKASI</a>
                        </div>
                      </div>
                    </div>  	
                    
              </div>
        </div>
      </div>
    </div>




<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Inputkan Datanya</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                      <form action="<?php echo e(url('register')); ?>" method="POST">
                                  <?php echo e(csrf_field()); ?>

                              <div class="form-group row">
                                  <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama')); ?></label>

                                  <div class="col-md-8">
                                      <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                      <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($message); ?></strong>
                                          </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                              </div>

                              <div class="form-group row">
                                  <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                                  <div class="col-md-8">
                                      <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                      <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($message); ?></strong>
                                          </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                              </div>

                              <div class="form-group row">
                                  <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                                  <div class="col-md-8">
                                      <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                      <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($message); ?></strong>
                                          </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                              </div>

                              <div class="form-group row">
                                  <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ulangi Password')); ?></label>

                                  <div class="col-md-8">
                                      <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                  </div>
                              </div>

                          </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">
                                  <?php echo e(__('Register')); ?>

                                </button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                            </div>
                      </form>
                    </div>
                </div>
              </div>
    </div>


    <div class="modal fade" id="rolemahasiswaModal" tabindex="-1" role="dialog" aria-labelledby="rolemahasiswaModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Inputkan Datanya</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                      <form action="<?php echo e(url('registermahasiswa')); ?>" method="POST">
                                  <?php echo e(csrf_field()); ?>

                              <div class="form-group row">
                                  <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama')); ?></label>

                                  <div class="col-md-8">
                                      <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                      <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($message); ?></strong>
                                          </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                              </div>

                              <div class="form-group row">
                                  <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('NIM')); ?></label>

                                  <div class="col-md-8">
                                      <select id="mahasiswa_id" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="mahasiswa_id" value="<?php echo e(old('mahasiswa_id')); ?>" required autocomplete="mahasiswa_id" autofocus>
                                      <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($yu->id); ?>"><?php echo e($yu->id); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                      <?php if ($errors->has('mahasiswa_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mahasiswa_id'); ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($message); ?></strong>
                                          </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                              </div>

                              <div class="form-group row">
                                  <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>

                                  <div class="col-md-8">
                                      <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                      <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($message); ?></strong>
                                          </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                              </div>

                              <div class="form-group row">
                                  <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                                  <div class="col-md-8">
                                      <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                      <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                          <span class="invalid-feedback" role="alert">
                                              <strong><?php echo e($message); ?></strong>
                                          </span>
                                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                  </div>
                              </div>

                              <div class="form-group row">
                                  <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Ulangi Password')); ?></label>

                                  <div class="col-md-8">
                                      <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                  </div>
                              </div>

                          </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">
                                  <?php echo e(__('Register')); ?>

                                </button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                            </div>
                      </form>
                    </div>
                </div>
              </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/beranda/index.blade.php ENDPATH**/ ?>