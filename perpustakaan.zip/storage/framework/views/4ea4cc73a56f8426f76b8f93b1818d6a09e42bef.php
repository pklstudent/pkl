<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
							<?php if(session('sukses')): ?>
                            <div class="alert alert-succes" role="alert">
                             <?php echo e(session('sukses')); ?>

                            </div>
                            <?php endif; ?>

							<?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                             <?php echo e(session('error')); ?>

                            </div>
                            <?php endif; ?>
                <div class="row">

                <div class="col-md-12">
							<!-- PANEL NO PADDING -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Informasi</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body no-padding bg-primary text-center">
									<div class="padding-top-30 padding-bottom-30">
									<img src="<?php echo e($buku->getFoto()); ?>" class="img-square" alt="Avatar" width="100px" height="100px">
										<h3><?php echo e($buku->Judul); ?></h3>
									</div>
								</div>
							</div>
							<!-- END PANEL NO PADDING -->


							<div class="col-md-12">

							<!-- CONDENSED TABLE -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Tabel Buku</h3>
									<div class="right">
									<?php if(Auth::check() && Auth::user()->role =='admin'): ?>
									<button type="button" class="btn" data-toggle="modal" data-target="#exampleModal"><i class="btn btn-warning btn-sm">Tambah Penulis Lain</i></button>
									<?php endif; ?>
									</div>
								</div>
								<div class="panel-body">
									<table class="table table-condensed">
										<thead>
											<tr><th>No</th><th>Judul</th><th>Penulis</th><th>Lokasi</th></tr>
										</thead>
										<tbody>
											<tr>
											<td>
											<?php echo e($buku->id); ?>

											</td>
											<td>
											<?php echo e($buku->Judul); ?>

											</td>
											<td>
											<?php $__currentLoopData = $buku->penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            	 			<?php echo e($h->NamaBelakang); ?>,
											<?php echo e($h->NamaDepan); ?>

											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
											</td>
											<td>
											<?php echo e($buku->lokasi['NamaLokasi']); ?>

											</td>
										</tbody>
									</table>
								</div>
							</div>
							<!-- END CONDENSED TABLE -->

		</div>
					

			</div>
        </div>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Penulis</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
	<form action="/buku/<?php echo e($buku->id); ?>/addpenulis" method="POST" name="penulis">
                            <?php echo e(csrf_field()); ?>

							<div class="form-group">
								<label for="penulis">Penulis</label>
								<select class="form-control" id="penulis" name="penulis">
								<?php $__currentLoopData = $penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($a->id); ?>"><?php echo e($a->NamaDepan); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
	
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
        <button type="submit" class="btn btn-primary">simpan</button>
	</form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/buku/detail.blade.php ENDPATH**/ ?>