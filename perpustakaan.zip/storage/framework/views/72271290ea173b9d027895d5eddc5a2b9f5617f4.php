<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
							<?php if(session('sukses')): ?>
                            <div class="alert alert-succes" role="alert">
                             <?php echo e(session('sukses')); ?>

                            </div>
                            <?php endif; ?>

							<?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                             <?php echo e(session('error')); ?>

                            </div>
                            <?php endif; ?>
                <div class="row">

                <div class="col-md-12">
							<!-- PANEL NO PADDING -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Panel No Padding</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body no-padding bg-primary text-center">
									<div class="padding-top-30 padding-bottom-30">
										<i class="fa fa-thumbs-o-up fa-5x"></i>
										<h3>No Content Padding</h3>
									</div>
								</div>
							</div>
							<!-- END PANEL NO PADDING -->


							<div class="col-md-12">

							<!-- CONDENSED TABLE -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Condensed Table</h3>
									<div class="right">
									<?php if(Auth::check() && Auth::user()->role =='admin'): ?>
									<button type="button" class="btn" data-toggle="modal" data-target="#exampleModal"><a class="btn btn-info">Tambah</a></button>
									<?php endif; ?>
									</div>
								</div>
								<div class="panel-body">
									<table class="table table-condensed">
										<thead>
											<tr><th>No</th><th>Judul</th><th>Tahun</th><th>Ketua</th>
											<th>Bidang</th>
											<th>Kategori</th></tr>
										</thead>
										<tbody>
											<tr>
											<td>
											<?php echo e($pengabdian->id); ?>

											</td>
											<td>
											<?php echo e($pengabdian->Judul); ?>

											</td>
											<td><?php echo e($pengabdian->Tahun); ?></td>
											<td>
											<?php echo e($pengabdian->ketua['Nama']); ?>

											</td>
											<td>
											<?php echo e($pengabdian->kategori['Nama']); ?>

											</td>
											<td>
											<?php echo e($pengabdian->bidang['Nama']); ?>

											</td></tr>
										</tbody>
									</table>
								</div>
							</div>
							<!-- END CONDENSED TABLE -->

		</div>
					

			</div>
        </div>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
	<form action="<?php echo e(url('pengabdian/'.$pengabdian->id.'/addpenulis')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

							<div class="form-group">
							<label for="penulis">Dosen</label>
								<select class="form-control" id="dosen" name="dosen">
								<?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($a->id); ?>"><?php echo e($a->Nama); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							<label for="penulis">Bidang</label>
								<select class="form-control" id="bidang" name="bidang">
								<?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($a->id); ?>"><?php echo e($b->Nama); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							<label for="penulis">Kategori</label>
								<select class="form-control" id="kategori" name="kategori">
								<?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($c->id); ?>"><?php echo e($c->Nama); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>			
							</div>
	
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">simpan</button>
	</form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/pengabdian/detail.blade.php ENDPATH**/ ?>