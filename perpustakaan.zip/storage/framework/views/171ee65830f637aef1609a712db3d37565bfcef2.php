<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <!--tabel input-->
                        <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Ubah</h3>
                        </div>
                        <div class="panel-body">
                            <!--ubah nya gan-->
                            <form action="/publikasi/<?php echo e($publikasi->id); ?>/goeditpublikasi" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Judul</label>
                                <input name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($publikasi->Judul); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Judulnya</small>
                            </div>

                            <div class="form-group">
                                        <label for="exampleInputEmail1">Penulis</label>
                                        <div class="dropdown">
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Daftar Penulis<b class="caret"></b></button></a>
                                            <ul class="dropdown-menu">
                                            <?php $__currentLoopData = $penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php $checked = in_array($p->id, $checkeds) ? true : false; ?>
                                                    <div class="checkbox">
                                                    <?php echo e(Form::checkbox('penulis[]', $p->id, $checked)); ?>

                                                        <span><?php echo e($p->NamaDepan); ?></span>
                                                        </label>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <small id="emailHelp" class="form-text text-muted">Pilih Penulis</small>
                                        <a class="btn btn-sm" href="/penulis">Tambahkan Penulis</a>
                            </div>
       
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tahun</label>
                                <input name="Tahun_Terbit" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($publikasi->Tahun_Terbit); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Tahun</small>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Deskripsi</label>
                                <input name="Deskripsi" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($publikasi->Deskripsi); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Deskripsi</small>
                            </div>

                            <div class="form-group">
							<label for="pengabdian">Pengabdian</label>
								<select class="form-control" id="publikasi" name="IDPengabdian">
								<?php $__currentLoopData = $pengabdian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(old('IDPengabdian') == $be->id): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Judul); ?></option>
                                            <?php elseif( old('IDPengabdian') == null && isset($publikasi->pengabdian->id) && ($publikasi->pengabdian->id == $be->id)): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Judul); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($be->id); ?>"><?php echo e($be->Judul); ?></option>
                                            <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                                <a class="btn btn-sm" href="/pengabdian">Tambahkan Pengabdian</a> 
                            </div>
                            
                            <div class="form-group">
							<label for="penelitian">Penelitian</label>
								<select class="form-control" id="penelitian" name="IDPenelitian">
								<?php $__currentLoopData = $penelitian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								            <?php if(old('IDPenelitian') == $be->id): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Judul); ?></option>
                                            <?php elseif( old('IDPenelitian') == null && isset($publikasi->penelitian->id) && ($publikasi->penelitian->id == $be->id)): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Judul); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($be->id); ?>"><?php echo e($be->Judul); ?></option>
                                            <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                                <a class="btn btn-sm" href="/penelitian">Tambahkan Penelitian</a>
                            </div>

                            <div class="form-group">
							<label for="kategori">Jenis Publikasi</label>
								<select class="form-control" id="jenispublikasi" name="IDJenisPublikasi">
								<?php $__currentLoopData = $jenispublikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								            <?php if(old('IDJenisPublikasi') == $be->id): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama_Jenis); ?></option>
                                            <?php elseif( old('IDJenisPublikasi') == null && isset($publikasi->jenispublikasi->id) && ($publikasi->jenispublikasi->id == $be->id)): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama_Jenis); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($be->id); ?>"><?php echo e($be->Judul); ?></option>
                                            <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                            </form>
                            <!--ubah nya gan-->
                         </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/publikasi/editpublikasi.blade.php ENDPATH**/ ?>