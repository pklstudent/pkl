<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
							<?php if(session('sukses')): ?>
                            <div class="alert alert-succes" role="alert">
                             <?php echo e(session('sukses')); ?>

                            </div>
                            <?php endif; ?>

							<?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                             <?php echo e(session('error')); ?>

                            </div>
                            <?php endif; ?>
                <div class="row">

                        <div class="col-md-12">

                            <div class="panel">
                                <div class="panel-heading">
                                        <h3 class="panel-title">Ubah Data PKL dan KKM</h3>
                                </div>
                                <div class="panel-body">
                                <!--ini-->

                                <form action="/pklkkm/<?php echo e($pklkkm->id); ?>/goeditpklkkm" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Kode PKL dan KKM</label>
                                <input name="id" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($pklkkm->id); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Kode Pkl dan KKM</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="exampleInputEmail1">Judul</label>
                                <input name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($pklkkm->Judul); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Namanya</small>
                            </div>

                            <div class="form-group">
							<label for="pklkkm">Pembimbing</label>
								<select class="form-control" id="pklkkm" name="KodeDosen">
								<?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								            <?php if(old('KodeDosen') == $be->id): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                            <?php elseif( old('KodeDosen') == null && isset($pklkkm->dosen->id) && ($pklkkm->dosen->id == $be->id)): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($be->id); ?>"><?php echo e($be->Nama); ?></option>
                                            <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            <div class="form-group">
                                        <label for="exampleInputEmail1">Anggota Mahasiswa</label>
                                        <div class="dropdown">
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Pilih Anggotanya<b class="caret"></b></button></a>
                                            <ul class="dropdown-menu">
                                            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php $checked = in_array($j->id, $checkeds) ? true : false; ?>
                                                    <div class="checkbox">
                                                    <?php echo e(Form::checkbox('mahasiswa[]', $j->id, $checked)); ?>

                                                        <label value="<?php echo e($j->id); ?>">
                                                        <span><?php echo e($j->Nama); ?></span>
                                                        </label>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <small id="emailHelp" class="form-text text-muted">Pilih Yang Sesuai</small><br>
                            </div>
       
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tahun</label>
                                <input name="Tahun" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($pklkkm->Tahun); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Tanggal Lahir</small>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Laporan</label>
                                <input name="Laporan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($pklkkm->Laporan); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Angkatennya</small>
                            </div>

                            <div class="form-group">
							<label for="pklkkm">Mitra</label>
								<select class="form-control" id="pklkkm" name="IDMitra">
								<?php $__currentLoopData = $mitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								            <?php if(old('IDMitra') == $be->id): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                            <?php elseif( old('IDMitra') == null && isset($pklkkm->mitra->id) && ($pklkkm->mitra->id == $be->id)): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($be->id); ?>"><?php echo e($be->Nama); ?></option>
                                            <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>
                            
                            
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Sikat</button>
                        </form>
                                <!--GGlah-->
                                </div>
                            </div>        

                        </div>
                
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/pklkkm/editpklkkm.blade.php ENDPATH**/ ?>