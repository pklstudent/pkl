
<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
                            <?php if(session('sukses')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(session('sukses')); ?>

                                </div>
                            <?php endif; ?>
                <div class="row">
                <div class="col-md-12">
			<!-- TABLE HOVER -->
			<div class="panel">
				    <div class="panel-heading">
                        <h3 class="panel-title">Data Kategori</h3>
                        <div class="right">
                        <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                        <button type="button" class="btn" data-toggle="modal" data-target="#exampleModal"><a class="btn btn-success">Tambah Kategori</a></button>
                        <?php endif; ?>
                        </div>  
                    </div> 
				<div class="panel-body">
					<table class="table table-hover">
						<thead>
							<tr>
                            <th>No</th>
                            <th>Nama </th>
                            <th>Jumlah Dana</th>
                            <th>Sumber Dana</th>
                            </tr>
						</thead>
						<tbody>
                        
                        <?php $__currentLoopData = $data_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($pk->id); ?></td>
                            <td><a href="/kategori/<?php echo e($pk->id); ?>/detail"><?php echo e($pk->Nama); ?></a></td>
                            <td><?php echo e($pk->JumlahDana); ?></td>
                            <td><?php $__currentLoopData = $pk->sumberdana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul><li><?php echo e($a->Nama); ?></li></ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                            <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                            <td><a href="/kategori/<?php echo e($pk->id); ?>/hapus" class="btn btn-danger btn-sm" onclick="return confirm('Hapus nih ?')">Hapus</a></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
					</table>
                    <b>Halaman :</b>                   <span class="badge"><?php echo e($data_kategori->currentPage()); ?></span><br/>
                    <b> Jumlah Data :</b>              <span class="badge"> <?php echo e($data_kategori->total()); ?> </span><br/>
                    <b> Data Per Halaman : </b>         <span class="badge">  <?php echo e($data_kategori->perPage()); ?></span> <br/>
                
                
                    <?php echo e($data_kategori->links()); ?>

				</div>
			</div>
			<!-- END TABLE HOVER -->

		</div>

                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Inputkan Datanya</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                            <form action="/kategori/create" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Kode Kategori</label>
                                <input name="id" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="No Kategori">
                                <small id="emailHelp" class="form-text text-muted">Masukan Kode Sumber Dana</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="exampleInputEmail1">Kategori</label>
                                <input name="Nama" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
                                <small id="emailHelp" class="form-text text-muted">Masukan Namanya</small>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Jumlah Dana</label>
                                <input name="JumlahDana" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Jumlah Dana">
                                <small id="emailHelp" class="form-text text-muted">Masukan Jumlah Dananya</small>
                            </div>

                            <div class="form-group">
                                        <label for="exampleInputEmail1">Sumber Dana</label>
                                        <div class="dropdown">
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Daftar Sumber Dana<b class="caret"></b></button></a>
                                            <ul class="dropdown-menu">
                                            <?php $__currentLoopData = $sumberdana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <?php echo e(Form::checkbox('sumberdana[]', $pe->id)); ?>

                                                        <label value="<?php echo e($pe->id); ?>">
                                                        <span><?php echo e($pe->Nama); ?></span>
                                                        </label>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <small id="emailHelp" class="form-text text-muted">Pilih Sumber Dana</small><br>
                                        <a class="btn btn-sm" href="/sumberdana">Input Sumber Dana</a>
                            </div>

                           
                                                        
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        </form>
                    </div>
                    </div>
                </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/perpustakaan/resources/views/kategori/index.blade.php ENDPATH**/ ?>