
<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
							<?php if(session('sukses')): ?>
                            <div class="alert alert-succes" role="alert">
                             <?php echo e(session('sukses')); ?>

                            </div>
                            <?php endif; ?>

							<?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                             <?php echo e(session('error')); ?>

                            </div>
                            <?php endif; ?>
                <div class="row">

                <div class="col-md-12">
							<!-- PANEL NO PADDING -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Info Penelitian</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body no-padding bg-primary text-center">
									<div class="padding-top-30 padding-bottom-30">
										<i class="fa fa-thumbs-o-up fa-5x"></i>
										<h3>No Content Padding</h3>
									</div>
								</div>
							</div>
							<!-- END PANEL NO PADDING -->


							<div class="col-md-12">

							<!-- CONDENSED TABLE -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Info Penelitian</h3>
								</div>
								<div class="panel-body">
									<table class="table table-condensed">
										<thead>
											<tr><th>No</th><th>Judul</th><th>Tahun</th><th>Ketua</th><th>Anggota Penelitian</th>
											<th>Bidang</th>
											<th>Kategori</th><th>Laporan</th><th>Proposal</th></tr>
										</thead>
										<tbody>
											<tr>
											<td>
											<?php echo e($penelitian->id); ?>

											</td>
											<td>
											<?php echo e($penelitian->Judul); ?>

											</td>
											<td><?php echo e($penelitian->Tahun); ?></td>
											<td>
											<?php echo e($penelitian->dosene['Nama']); ?>

											</td>
                                            <td>
                                            <ul><?php $__currentLoopData = $penelitian->dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($p->Nama); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $penelitian->mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($o->Nama); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
                                            </td>
											<td>
											<?php echo e($penelitian->kategori['Nama']); ?>

											</td>
											<td>
											<?php echo e($penelitian->bidang['Nama']); ?>

											</td>
											<td><?php echo e($penelitian->Laporan); ?></td>
                            				<td><?php echo e($penelitian->Proposal); ?></td></tr>
										</tbody>
									</table>
								</div>
							</div>
							<!-- END CONDENSED TABLE -->

		</div>
					

			</div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/perpustakaan/resources/views/penelitian/detail.blade.php ENDPATH**/ ?>