<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <!--tabel input-->
                        <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Ubah</h3>
                            
                            <?php if(session('sukses')): ?>
                            <div class="alert alert-succes" role="alert">
                             <?php echo e(session('sukses')); ?>

                            </div>
                            <?php endif; ?>
                            
                        </div>
                        <div class="panel-body">
                            <!--ubah nya gan-->
                            
                <form action="/pengabdian/<?php echo e($pengabdian->id); ?>/goeditpengabdian" method="post">
                        <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Judul</label>
                                <input required="required" name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($pengabdian->Judul); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Judul</small>
                            </div>
       
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tahun</label>
                                <input name="Tahun" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($pengabdian->Tahun); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Penerbit Buku</small>
                            </div>

                            <div class="form-group">
							<label for="penulis">Ketua</label>
								<select class="form-control" id="pengabdian" name="ketua_id">
								<?php $__currentLoopData = $ketua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								        <?php if(old('ketua_id') == $be->id): ?>
                                            <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                        <?php elseif( old('ketua_id') == null && isset($pengabdian->ketua->id) && ($pengabdian->ketua->id == $be->id)): ?>
                                            <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($be->id); ?>"><?php echo e($be->Nama); ?></option>
                                        <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            <div class="form-group">
                                        <label for="exampleInputEmail1">Anggota</label>
                                        <div class="dropdown">
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Ubah Anggota<b class="caret"></b></button></a>
                                            <ul class="dropdown-menu">
                                            <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                <?php $checked = in_array($p->id, $checkeds) ? true : false; ?>
                                                    <div class="checkbox">
                                                    <?php echo e(Form::checkbox('dosen[]', $p->id, $checked)); ?>

                                                        <span><?php echo e($p->Nama); ?></span>
                                                        </label>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                <?php $checkeda = in_array($yu->id, $checkedsa) ? true : false; ?>
                                                    <div class="checkbox">
                                                    <?php echo e(Form::checkbox('mahasiswa[]', $yu->id, $checkeda)); ?>

                                                        <span><?php echo e($yu->Nama); ?></span>
                                                        </label>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <small id="emailHelp" class="form-text text-muted">Pilih Penulis</small>
                            </div>

                            <div class="form-group">
							<label for="penulis">Kategori</label>
								<select class="form-control" id="kategori" name="kategori_id">
								<?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(old('kategori_id') == $be->id): ?>
                                            <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                        <?php elseif( old('kategori_id') == null && isset($pengabdian->kategori->id) && ($pengabdian->kategori->id == $be->id)): ?>
                                            <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($be->id); ?>"><?php echo e($be->Nama); ?></option>
                                        <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            <div class="form-group">
							<label for="penulis">Bidang</label>
								<select class="form-control" id="bidang" name="bidang_id">
								<?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(old('bidang_id') == $be->id): ?>
                                            <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                        <?php elseif( old('bidang_id') == null && isset($pengabdian->bidang->id) && ($pengabdian->bidang->id == $be->id)): ?>
                                            <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($be->id); ?>"><?php echo e($be->Nama); ?></option>
                                        <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>
                    <div class="modal-footer">
                    <input type="submit" value="Simpan" class="btn btn-dark">   
                
                </form>
            
                        </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
   

<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/pengabdian/editpengabdian.blade.php ENDPATH**/ ?>