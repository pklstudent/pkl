<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
							<?php if(session('sukses')): ?>
                            <div class="alert alert-succes" role="alert">
                             <?php echo e(session('sukses')); ?>

                            </div>
                            <?php endif; ?>

							<?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                             <?php echo e(session('error')); ?>

                            </div>
                            <?php endif; ?>
                <div class="row">

                <div class="col-md-12">
							<!-- PANEL NO PADDING -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Info Penelitian</h3>
								</div>
							</div>
							<!-- END PANEL NO PADDING -->


							<div class="col-md-12">

							<!-- CONDENSED TABLE -->
							<div class="panel">
								<div>
									<table class="table">
										<thead>
											<tr><th>No</th><th>Judul</th><th>Tahun</th><th>Ketua</th><th>Anggota Penelitian</th>
											<th>Bidang</th>
											<th>Kategori</th><th>Laporan</th><th>Proposal</th></tr>
										</thead>
										<tbody>
											<tr>
											<td>
											<?php echo e($penelitian->id); ?>

											</td>
											<td>
											<?php echo e($penelitian->Judul); ?>

											</td>
											<td><?php echo e($penelitian->Tahun); ?></td>
											<td>
											<?php echo e($penelitian->dosene['Nama']); ?>

											</td>
                                            <td>
                                            <ul><?php $__currentLoopData = $penelitian->dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($p->Nama); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $penelitian->mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($o->Nama); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
                                            </td>
											<td>
											<?php echo e($penelitian->kategori['Nama']); ?>

											</td>
											<td>
											<?php echo e($penelitian->bidang['Nama']); ?>

											</td>
											<td>
											<?php if(!empty($penelitian->getLaporan())): ?>
												<a href="<?php echo e($penelitian->getLaporan()); ?>" class="btn btn-warning">Laporan</a>
											<?php else: ?>
												---
											<?php endif; ?>
											</td>
                            				<td><?php echo e($penelitian->Proposal); ?></td></tr>
										</tbody>
									</table>
								</div>
								<div class="panel-heading">
									<h3 class="panel-title">Publikasi</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
									</div>
								</div>
								<div class="panel-body">
									<ol>
									<?php $__currentLoopData = $penelitian->publikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><?php $__currentLoopData = $pub->penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php echo e($ce->NamaBelakang); ?>, <?php echo e($ce->NamaDepan); ?>;
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><br>(<?php echo e($pub->Tahun_Terbit); ?>). <a href="<?php echo e(url('publikasi/'.$pub->id.'/detail')); ?>"><?php echo e($pub->Judul); ?></a>. <?php echo e($pub->Deskripsi); ?></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ol>
								</div>
							</div>
							<!-- END CONDENSED TABLE -->

		</div>
					

			</div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/penelitian/detail.blade.php ENDPATH**/ ?>