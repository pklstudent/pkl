<?php $__env->startSection('content'); ?>
<div class="main">
        <div class="main-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <div class="panel">
                                <div class="panel-heading">
                                        <h3 class="panel-title">Styled Checkboxes and Radios</h3>
                                </div>
                                <div class="panel-body">
                                <form action="/buku/{id}/goeditpenulis" method="POST"name="buku">
                                <?php echo e(csrf_field()); ?>

                                <!-- panelnya-->
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">No</label>
                                        <input required="required" name="id" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($buku->id); ?>">
                                        <small id="emailHelp" class="form-text text-muted">Masukan No Setelah Terakhir</small>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Judul</label>
                                        <input required="required"  name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($buku->Judul); ?>">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Judul</small>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Penulis</label>
                                        <div class="dropdown">
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Daftar Penulis<b class="caret"></b></button></a>
                                            <ul class="dropdown-menu">
                                            <?php $__currentLoopData = $penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <?php $checked = in_array($p->id, $checkeds) ? true : false; ?>
                                                    <div class="checkbox">
                                                        <label>
                                                        <?php echo e(Form::checkbox('penulis[]', $p->id, $checked)); ?>

                                                        <span><?php echo e($p->NamaDepan); ?></span>
                                                        </label>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <small id="emailHelp" class="form-text text-muted">Pilih Penulis</small>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Penerbit</label>
                                        <input name="Penerbit" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($buku->Penerbit); ?>">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Penerbit Buku</small>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Tahun</label>
                                        <input name="Tahun" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  value="<?php echo e($buku->Tahun); ?>">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Tahun Terbit</small>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Banyak</label>
                                        <input name="Banyak" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($buku->Banyak); ?>">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Banyaknya Buku</small>
                                    </div>

                                    <div class="form-group">
                                    <label for="penulis">Lokasi</label>
                                        <select class="form-control" id="lokasi" name="lokasi_id">
                                        <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ce->id); ?>"><?php echo e($ce->NamaLokasi); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                <!--ini doang-->
                                    <div class="modal-footer">
                                    <input type="submit" value="Simpan" class="btn btn-dark">
                                </form>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/buku/ubah.blade.php ENDPATH**/ ?>