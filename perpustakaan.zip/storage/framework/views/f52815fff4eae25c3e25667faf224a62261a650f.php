<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
							<?php if(session('sukses')): ?>
                            <div class="alert alert-succes" role="alert">
                             <?php echo e(session('sukses')); ?>

                            </div>
                            <?php endif; ?>

							<?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                             <?php echo e(session('error')); ?>

                            </div>
                            <?php endif; ?>
                <div class="row">

                        <div class="col-md-12">

                            <div class="panel">
                                <div class="panel-heading">
                                        <h3 class="panel-title">Ubah Data Penelitian</h3>
                                </div>
                                <div class="panel-body">

                                <form action="/penelitian/<?php echo e($penelitian->id); ?>/goeditpenelitian" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Judul</label>
                                <input name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($penelitian->Judul); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Judulnya</small>
                            </div>

                            <div class="form-group">
							<label for="penelitian">Ketua</label>
								<select class="form-control" id="penelitian" name="dosene_id">
								<?php $__currentLoopData = $dosene; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if(old('dosene_id') == $be->id): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                            <?php elseif( old('dosene_id') == null && isset($penelitian->dosene->id) && ($penelitian->dosene->id == $be->id)): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($be->id); ?>"><?php echo e($be->Nama); ?></option>
                                            <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            <div class="form-group">
                                        <label for="exampleInputEmail1">Anggota</label>
                                        <div class="dropdown">
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Daftar Anggota<b class="caret"></b></button></a>
                                            <ul class="dropdown-menu">
                                            <div style="OVERFLOW-Y:scroll; WIDTH:600px; HEIGHT:300px">
                                            <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                <?php $checked = in_array($p->id, $checkeds) ? true : false; ?>
                                                    <?php echo e(Form::checkbox('dosen[]', $p->id, $checked)); ?>

                                                        <span><?php echo e($p->Nama); ?></span>
                                                        </label>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                <?php $checkeda = in_array($yu->id, $checkedsa) ? true : false; ?>
                                                    <?php echo e(Form::checkbox('mahasiswa[]', $yu->id, $checkeda)); ?>

                                                        <span><?php echo e($yu->Nama); ?></span>
                                                        </label>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            </ul>
                                        </div>
                                        <small id="emailHelp" class="form-text text-muted">Pilih Anggota</small><br>
                            </div>
       
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tahun</label>
                                <input name="Tahun" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($penelitian->Tahun); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Tahun</small>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Laporan</label>
                                <input name="Laporan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($penelitian->Laporan); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Laporan</small>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Proposal</label>
                                <input name="Proposal" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="<?php echo e($penelitian->Proposal); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Proposal</small>
                            </div>  
                            
                            <div class="form-group">
							<label for="bidang">Bidang</label>
								<select class="form-control" id="bidang" name="bidang_id">
								<?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								            <?php if(old('bidang_id') == $be->id): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                            <?php elseif( old('bidang_id') == null && isset($penelitian->bidang->id) && ($penelitian->bidang->id == $be->id)): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($be->id); ?>"><?php echo e($be->Nama); ?></option>
                                            <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            <div class="form-group">
							<label for="kategori">Kategori</label>
								<select class="form-control" id="kategori" name="kategori_id">
								<?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								            <?php if(old('kategori_id') == $be->id): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                            <?php elseif( old('kategori_id') == null && isset($penelitian->kategori->id) && ($penelitian->kategori->id == $be->id)): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($be->id); ?>"><?php echo e($be->Nama); ?></option>
                                            <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        </form>

                                </div>
                            </div>        

                        </div>
                
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/penelitian/editpenelitian.blade.php ENDPATH**/ ?>