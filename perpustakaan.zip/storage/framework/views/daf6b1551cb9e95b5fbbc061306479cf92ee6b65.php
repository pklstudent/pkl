
<?php $__env->startSection('content'); ?>
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="panel panel-profile">
						<div class="clearfix">
							<!-- LEFT COLUMN -->
							<div class="profile-center">
								<!-- PROFILE HEADER -->
								<div class="profile-header">
									<div class="overlay"></div>
									<div class="profile-main">
										<img src="<?php echo e($dosen->getProfil()); ?>" class="img-circle" alt="Avatar"  width="200px" height="200px">
										<h3 class="name"><?php echo e($dosen->Nama); ?></h3>
										<span class="online-status status-available"><?php echo e($dosen->Status); ?></span>
									</div>
									<div class="profile-stat">
										<div class="row">
											<div class="col-md-12 stat-item">
												<b>Bidang</b> <span><?php echo e($dosen->Bidang); ?></span>
											</div>
										</div>
									</div>
								</div>
								<!-- END PROFILE HEADER -->
								<!-- PROFILE DETAIL -->
								<div class="profile-detail">
									<div class="profile-info">
										<h4 class="heading">Info Dosen</h4>
										<ul class="list-unstyled list-justify">
											<li>Golongan <span><?php echo e($dosen->Golongan); ?></span></li>
											<li>Tanggal Lahir<span><?php echo e($dosen->TglLahir); ?></span></li>
											<li>Gender<span><?php echo e($dosen->Gender); ?></span></li>
                                            <li>Alamat <span><?php echo e($dosen->Alamat); ?></span></li>
										</ul>
									</div>
									<?php if(Auth::check() && Auth::user()->role =='admin'): ?>
									<div class="text-center"><a href="/dosen/<?php echo e($dosen->id); ?>/editdosen" class="btn btn-primary">Ubah Profilnya</a></div>
									<?php endif; ?>
								</div>
								<!-- END PROFILE DETAIL -->
								<div class="panel">
									<div class="panel-heading">
										<h3 class="panel-title">Track Record</h3>
									</div>
									<div class="panel-body">
										<table class="table table-bordered">
											<thead>
												<tr><th>Penelitian</th><th>Pengabdian</th>
											</thead>
											<tbody>
												<tr>
												<td>
												<ul class="list list-justify">
													<?php $__currentLoopData = $dosen->penelitian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li><?php echo e($tr->Judul); ?></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
												</td>
												<td>
												<ul class="list list-justify">
													<?php $__currentLoopData = $dosen->Pengabdian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li><?php echo e($tb->Judul); ?></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
												</td></tr>
											</tbody>
										</table>
									</div>
									</div>
								<!--Tabel-->
							</div>
							<!-- END LEFT COLUMN -->
					
						</div>
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/perpustakaan/resources/views/dosen/detail.blade.php ENDPATH**/ ?>