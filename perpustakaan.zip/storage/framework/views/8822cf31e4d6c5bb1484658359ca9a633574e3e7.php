<?php $__env->startSection('content'); ?>
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="panel panel-profile">
						<div class="clearfix">
							<!-- LEFT COLUMN -->
							<div class="profile-center">
								<!-- PROFILE HEADER -->
								<div class="profile-header">
									<div class="overlay"></div>
									<div class="profile-main">
									<img src="<?php echo e($mahasiswa->getFotomhs()); ?>" class="img-circle" alt="Avatar" witdh="100px" height="100px">
										<h3 class="name"><?php echo e($mahasiswa->Nama); ?></h3>
									</div>
									<div class="profile-stat">
										<div class="row">
											<div class="col-md-12 stat-item">
												<b></b> <span></span>
											</div>
										</div>
									</div>
								</div>
								<!-- END PROFILE HEADER -->
								<!-- PROFILE DETAIL -->
								<div class="profile-detail">
									<div class="profile-info">
										<h4 class="heading">Info Mahasiswa</h4>
										<ul class="list-unstyled list-justify">
											<li>Tanggal Lahir<span><?php echo e($mahasiswa->Tgl_Lahir); ?></span></li>
											<li>Gender<span><?php echo e($mahasiswa->Gender); ?></span></li>
											<li>Alamat <span><?php echo e($mahasiswa->Alamat); ?></span></li>
                                            <?php $__currentLoopData = $mahasiswa->pklkkm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li>PKL dan KKM<span><?php echo e($a->Judul); ?></span></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</ul>
										<?php if(auth()->user()): ?>
									</div>
									<div class="text-center"><a href="/mahasiswa/<?php echo e($mahasiswa->id); ?>/editmahasiswa" class="btn btn-primary">Ubah Profilnya</a></div>
								</div>
								<?php endif; ?>
								<!-- END PROFILE DETAIL -->
							</div>
							<!-- END LEFT COLUMN -->
					
						</div>
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/mahasiswa/detail.blade.php ENDPATH**/ ?>