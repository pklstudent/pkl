<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
                            <?php if(session('sukses')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(session('sukses')); ?>

                                </div>
                            <?php endif; ?>
                <div class="row">
                <div class="col-md-12">
			<!-- TABLE HOVER -->
			<div class="panel">
				    <div class="panel-heading">
                        <h3 class="panel-title">Data Publikasi</h3>
                        <div class="right">
                        <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                        <a href="<?php echo e(url('publikasi/createpublikasi')); ?>" class="btn btn-info btn-sm"><i  class="glyphicon glyphicon-plus-sign"></i> Tambah Data Publikasi</a>
                        <?php endif; ?>
                        </div>  
                    </div> 
				<div class="panel-body">
                <form action="<?php echo e(url('publikasi')); ?>" method="get">
                    <div class="input-group">
                                                <input class="form-control" name="cari" type="text" placeholder="Tulis Judulnya">
                                                <span  class="input-group-btn"><button class="btn btn-primary">Cari</button></span> 
                    </div>
                </form>
                <br>
					<table class="table table-hover">
						<thead>
							<tr>
                            <th>No</th>
                            <th>Judul</th>
                            <th>Penulis</th>
                            <th>Tahun</th>
                            <th>Deskripsi</th>
                            <th>Jenis Publikasi</th>
                            </tr>
						</thead>
						<tbody>
                        
                        <?php $__currentLoopData = $data_publikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pe->id); ?></td>
                            <td><a href="<?php echo e(url('publikasi/'.$pe->id.'/detail')); ?>"><?php echo e($pe->Judul); ?></a></td>
                            <td>
                            <?php $__currentLoopData = $pe->penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul><li><?php echo e($ce->NamaBelakang); ?>,<?php echo e($ce->NamaDepan); ?></li></ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($pe->Tahun_Terbit); ?></td>
                            <td><?php echo e($pe->Deskripsi); ?></td>
                            
                            <td><?php echo e($pe->jenispublikasi['Nama_Jenis']); ?></td>
                            <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                            <td><a href="<?php echo e(url('publikasi/'.$pe->id.'/editpublikasi')); ?>" class="btn btn-warning btn-sm" >Ubah</a></td>
                            <td><a href="<?php echo e(url('publikasi/hapus/'.$pe->id)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus nih ?')">Hapus</a></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
					</table>
                    <b>Halaman :</b>                   <span class="badge"><?php echo e($data_publikasi->currentPage()); ?></span><br/>
                    <b> Jumlah Data :</b>              <span class="badge"> <?php echo e($data_publikasi->total()); ?> </span><br/>
                    <b> Data Per Halaman : </b>         <span class="badge">  <?php echo e($data_publikasi->perPage()); ?></span> <br/>
                
                
                    <?php echo e($data_publikasi->links()); ?>

				</div>
			</div>
			<!-- END TABLE HOVER -->

		</div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/publikasi/index.blade.php ENDPATH**/ ?>