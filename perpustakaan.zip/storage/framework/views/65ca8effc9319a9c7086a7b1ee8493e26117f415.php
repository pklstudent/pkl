
<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
                            <?php if(session('sukses')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(session('sukses')); ?>

                                </div>
                            <?php endif; ?>
                <div class="row">

                <div class="col-md-12">

			<!-- TABLE HOVER -->
			<div class="panel">
				    <div class="panel-heading">
                        <h3 class="panel-title">Data Mahasiswa</h3>
                        <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                        <div class="right">
                        <button type="button" class="btn" data-toggle="modal" data-target="#exampleModal"><a class="btn btn-success">Tambah Data Siswa</a></button>
                        </div>
                        <?php endif; ?>  
                    </div>
				<div class="panel-body">
                <form action="/mahasiswa" method="get">
                    <div class="input-group">
                                                <input class="form-control" name="cari" type="text" placeholder="Tulis Nama Mahasiswa">
                                                <span  class="input-group-btn"><button class="btn btn-primary">Cari</button></span> 
                    </div>
                </form>
                <br>
					<table class="table table-hover">
						<thead>
							<tr>
                            <th>NIM</th>
                            <th>Nama</th>
                            <th>Angkatan</th>
                            </tr>
						</thead>
						<tbody>
                        
                        <?php $__currentLoopData = $data_mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($mahasiswa->id); ?></td>
                            <td><a href="/mahasiswa/<?php echo e($mahasiswa->id); ?>/detail"><?php echo e($mahasiswa->Nama); ?></a></td>
                            <td><?php echo e($mahasiswa->Angkatan); ?></td>
                            <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                            <td><a href="/mahasiswa/<?php echo e($mahasiswa->id); ?>/editmahasiswa" class="btn btn-warning btn-sm" >Ubah</a></td>
                            <td><a href="/mahasiswa/<?php echo e($mahasiswa->id); ?>/hapus" class="btn btn-danger btn-sm" onclick="return confirm('Hapus nih ?')">Hapus</a></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
					</table>
                    <b>Halaman :</b>                   <span class="badge"><?php echo e($data_mahasiswa->currentPage()); ?></span><br/>
                    <b> Jumlah Data :</b>              <span class="badge"> <?php echo e($data_mahasiswa->total()); ?> </span><br/>
                    <b> Data Per Halaman : </b>         <span class="badge">  <?php echo e($data_mahasiswa->perPage()); ?></span> <br/>
                
                
                    <?php echo e($data_mahasiswa->links()); ?>

				</div>
			</div>
			<!-- END TABLE HOVER -->

		</div>

                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Inputkan Datanya</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                            <form action="/mahasiswa/create" method="POST" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">NIM</label>
                                <input name="id" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="NIM">
                                <small id="emailHelp" class="form-text text-muted">Masukan NIM Mahasiswa</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="exampleInputEmail1">Nama</label>
                                <input name="Nama" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama">
                                <small id="emailHelp" class="form-text text-muted">Masukan Namanya</small>
                            </div>
       
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tanggal Lahir</label>
                                <input name="Tgl_Lahir" type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Tanggal Lahir">
                                <small id="emailHelp" class="form-text text-muted">Masukan Tanggal Lahir</small>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Angkatan</label>
                                <input name="Angkatan" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Angkatan">
                                <small id="emailHelp" class="form-text text-muted">Masukan Angkatennya</small>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Gender</label>
                               <select name="Gender" id="Gender" class="form-control">
                               <option value="Laki-laki">Laki-laki</option>
                               <option value="Perempuan">Perempuan</option>
                               </select>
                                <small id="emailHelp" class="form-text text-muted">Masukan Gendernya</small>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Alamat</label>
                                <input name="Alamat" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Alamat">
                                <small id="emailHelp" class="form-text text-muted">Masukan Alamat</small>
                            </div>

                            <div class="form-group">
                                                        <label for="exampleInputEmail1">Foto</label>
                                                        <input name="fotomhs" type="file" class="form-control">
                                                        <small id="emailHelp" class="form-text text-muted">Masukan Fotonya</small>
                            </div>
                            
                            
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        </form>
                    </div>
                    </div>
                </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/perpustakaan/resources/views/mahasiswa/index.blade.php ENDPATH**/ ?>