<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <div class="panel">
                                <div class="panel-heading">
                                        <h3 class="panel-title">Ubah Data Buku</h3>
                                </div>
                                <div class="panel-body">
                                <form action="/buku/<?php echo e($buku->id); ?>/goeditbuku" method="POST" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <!-- panelnya-->                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Judul</label>
                                        <input required="required"  name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($buku->Judul); ?>">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Judul</small>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Penulis</label>
                                        <div class="dropdown">
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Daftar Penulis<b class="caret"></b></button></a>
                                            <ul class="dropdown-menu">
                                            <div style="OVERFLOW-Y:scroll; WIDTH:300px; HEIGHT:300px"> 
                                            <?php $__currentLoopData = $penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <?php $checked = in_array($p->id, $checkeds) ? true : false; ?>
                                                        <label>
                                                        <?php echo e(Form::checkbox('penulis[]', $p->id, $checked)); ?>

                                                        <span><?php echo e($p->NamaDepan); ?></span>
                                                        </label>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            </ul>
                                        </div>
                                        <small id="emailHelp" class="form-text text-muted">Pilih Penulis</small>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Penerbit</label>
                                        <input name="Penerbit" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($buku->Penerbit); ?>">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Penerbit Buku</small>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Tahun</label>
                                        <input name="Tahun" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  value="<?php echo e($buku->Tahun); ?>">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Tahun Terbit</small>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Banyak</label>
                                        <input name="Banyak" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($buku->Banyak); ?>">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Banyaknya Buku</small>
                                    </div>

                                    <div class="form-group">
                                    <label for="penulis">Lokasi</label>
                                        <select class="form-control" id="lokasi" name="lokasi_id">
                                        <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(old('lokasi_id') == $be->id): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->NamaLokasi); ?></option>
                                            <?php elseif( old('lokasi_id') == null && isset($buku->lokasi->id) && ($buku->lokasi->id == $be->id)): ?>
                                                <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->NamaLokasi); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($be->id); ?>"><?php echo e($be->NamaLokasi); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Bidang</label>
                                        <div class="dropdown">
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Daftar Bidang<b class="caret"></b></button></a>
                                            <ul class="dropdown-menu">
                                            <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <?php $checkeda = in_array($j->id, $checkedsa) ? true : false; ?>
                                                    <?php echo e(Form::checkbox('bidang[]', $j->id, $checkeda)); ?>

                                                        <label>
                                                        <span><?php echo e($j->Nama); ?></span>
                                                        </label>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <small id="emailHelp" class="form-text text-muted">Pilih Bidang</small>
                                    </div>

                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Foto</label>
                                                        <input name="foto" type="file" class="form-control">
                                                        <small id="emailHelp" class="form-text text-muted">Masukan Foto</small>
                                    </div>

                                <!--ini doang-->
                                    <div class="modal-footer">
                                    <input type="submit" value="Simpan" class="btn btn-dark">
                                </form>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/buku/editbuku.blade.php ENDPATH**/ ?>