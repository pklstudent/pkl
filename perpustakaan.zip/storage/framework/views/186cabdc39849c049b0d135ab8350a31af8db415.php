<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <!--tabel input-->
                        <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Ubah</h3>
                        </div>
                            <div class="panel-body">
                            <!--ubah nya gan-->
                            <form action="/skripsi/<?php echo e($skripsi->id); ?>/goeditskripsi" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Judul</label>
                                <input name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($skripsi->Judul); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Judul</small>
                            </div>

                            <div class="form-group">
							<label for="skripsi">Nama Mahasiswa</label>
								<select class="form-control" id="skripsi" name="mahasiswa_id">
								<?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								        <?php if(old('mahasiswa_id') == $ce->id): ?>
                                            <option value="<?php echo e($ce->id); ?>" selected="selected"><?php echo e($ce->Nama); ?></option>
                                        <?php elseif( old('mahasiswa_id') == null && isset($skripsi->mahasiswa->id) && ($skripsi->mahasiswa->id == $ce->id)): ?>
                                            <option value="<?php echo e($ce->id); ?>" selected="selected"><?php echo e($ce->Nama); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($ce->id); ?>"><?php echo e($ce->Nama); ?></option>
                                        <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            <div class="form-group">
							<label for="skripsi">Nama Pembimbing Satu</label>
								<select class="form-control" id="skripsi1" name="pembimbing1_id">
								<?php $__currentLoopData = $pembimbing1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $we): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(old('pembimbing1_id') == $we->id): ?>
                                            <option value="<?php echo e($we->id); ?>" selected="selected"><?php echo e($we->Nama); ?></option>
                                        <?php elseif( old('pembimbing1_id') == null && isset($skripsi->pembimbing1->id) && ($skripsi->pembimbing1->id == $we->id)): ?>
                                            <option value="<?php echo e($we->id); ?>" selected="selected"><?php echo e($we->Nama); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($we->id); ?>"><?php echo e($we->Nama); ?></option>
                                        <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            <div class="form-group">
							<label for="skripsi">Nama Pembimbing Dua</label>
								<select class="form-control" id="skripsi2" name="pembimbing2_id">
								<?php $__currentLoopData = $pembimbing2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(old('pembimbing2_id') == $be->id): ?>
                                            <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                        <?php elseif( old('pembimbing2_id') == null && isset($skripsi->pembimbing2->id) && ($skripsi->pembimbing2->id == $be->id)): ?>
                                            <option value="<?php echo e($be->id); ?>" selected="selected"><?php echo e($be->Nama); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($be->id); ?>"><?php echo e($be->Nama); ?></option>
                                        <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>
       
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tahun</label>
                                <input name="Tahun" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($skripsi->Tahun); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Tahun</small>
                            </div>

                            <div class="form-group">
                                <label for="skripsi">Bidang</label>
                                    <select class="form-control" id="skripsi" name="bidang_id">
                                    <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $we): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(old('bidang_id') == $we->id): ?>
                                            <option value="<?php echo e($we->id); ?>" selected="selected"><?php echo e($we->Nama); ?></option>
                                        <?php elseif( old('bidang_id') == null && isset($skripsi->bidang->id) && ($skripsi->bidang->id == $we->id)): ?>
                                            <option value="<?php echo e($we->id); ?>" selected="selected"><?php echo e($we->Nama); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($we->id); ?>"><?php echo e($we->Nama); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                            <div class="form-group">
                                                        <label for="File">File</label>
                                                        <input name="File" type="file" class="form-control" accept="application/pdf" />
                                                        <small id="emailHelp" class="form-text text-muted">Masukan Filenya</small>
                            </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><a href="<?php echo e(url()->previous()); ?>"> Kembali</a></button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        </form>
                            <!--ubah nya gan-->
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/skripsi/editskripsi.blade.php ENDPATH**/ ?>