<?php $__env->startSection('content'); ?>
<div class="main-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">

                        <div class="panel">
                                <div class="panel-heading">
                                        <h3 class="panel-title">Buat Data Buku</h3>
                                        <div class="right">
                                        </div>
                                </div>
                                <div class="panel-body">
                                <form action="/skripsi/create" method="POST" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Kode skripsi</label>
                                    <input name="id" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Bisa dikosongi ataupun diisi">
                                    <small id="emailHelp" class="form-text text-muted">Masukan Nomor Terakhir</small>
                                </div>
                                
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Judul</label>
                                    <input name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Judul">
                                    <small id="emailHelp" class="form-text text-muted">Masukan Judul</small>
                                </div>

                                <div class="form-group">
                                <label for="skripsi">NIM</label>
                                    <select class="form-control" id="mahasiswa" name="mahasiswa_id">
                                    <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ce->id); ?>"><?php echo e($ce->id); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#mahasiswaModal">
                                                        Tambah Mahasiswa
                                                </button><br>              
                                </div>

                                <div class="form-group">
                                <label for="skripsi">Nama Pembimbing Satu</label>
                                    <select class="form-control" id="dosen" name="pembimbing1_id">
                                    <?php $__currentLoopData = $pembimbing1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $de): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($de->id); ?>"><?php echo e($de->Nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#dosenModal">
                                                        Tambah Dosen
                                                </button>
                                </div>

                                <div class="form-group">
                                <label for="skripsi">Nama Pembimbing Dua</label>
                                    <select class="form-control" id="dosenk" name="pembimbing2_id">
                                    <?php $__currentLoopData = $pembimbing2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($be->id); ?>"><?php echo e($be->Nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#dosenModal">
                                                        Tambah Dosen
                                                </button>
                                </div>
        
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tahun</label>
                                    <input name="Tahun" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Tahun">
                                    <small id="emailHelp" class="form-text text-muted">Masukan Tahun</small>
                                </div>

                                <div class="form-group">
                                <label for="skripsi">Bidang</label>
                                    <select class="form-control" id="skripsi" name="bidang_id">
                                    <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $we): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($we->id); ?>"><?php echo e($we->Nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                                        <label for="File">File</label>
                                                        <input name="File" type="file" class="form-control" accept="application/pdf" />
                                                        <small id="emailHelp" class="form-text text-muted">Masukan Filenya</small>
                                </div>
                                
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><a href="<?php echo e(url()->previous()); ?>"> Kembali</a></button>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                            </form>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
<?php echo $__env->make('campuran.mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('campuran.dosen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('auto'); ?>
<script>
$(document).ready(function(){
    $('#addmahasiswa').submit(function( event ) {
        event.preventDefault();
        $.ajax({
            url: '/mahasiswa/create',
            type: 'post',
            data: $('#addmahasiswa').serialize(), // Remember that you need to have your csrf token included
            dataType: 'json',
            success: function(success){
                console.log(success)
                $('#mahasiswaModal').modal('hide'),
                alert("Data Dah Di Save");             
            },
            error: function(error){
                console.log(error)
                alert("Data Tidak Ke Save");
            }
            })
            .done(function(res) {
            // make new option based on ajax response
            var input = '<option value="'+ res.id +'">'+ res.id +'</option>';
            // append option to catogory select
            $('#mahasiswa').append(input);
            });
    });
    $('#submit').click,
    $('#adddosen').submit(function( event ) {
        event.preventDefault();
        $.ajax({
            url: '/dosen/create',
            type: 'post',
            data: $('#adddosen').serialize(), // Remember that you need to have your csrf token included
            dataType: 'json',
            success: function(success){
                console.log(success)
                $('#dosenModal').modal('hide'),
                alert("Data Dah Di Save");             
            },
            error: function(error){
                console.log(error)
                alert("Data Tidak Ke Save");
            }
            })
            .done(function(res) {
            // make new option based on ajax response
            var input='<option value="'+ res.id +'">'+ res.Nama +'</option>';
            // append option to catogory select
            $('#dosen').append(input);
            $('#dosenk').append(input);
            });
    });
    $('#submit').click
});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/skripsi/createskripsi.blade.php ENDPATH**/ ?>