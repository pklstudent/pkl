
<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
							<?php if(session('sukses')): ?>
                            <div class="alert alert-succes" role="alert">
                             <?php echo e(session('sukses')); ?>

                            </div>
                            <?php endif; ?>

							<?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                             <?php echo e(session('error')); ?>

                            </div>
                            <?php endif; ?>
                <div class="row">

                        <div class="col-md-12">

                            <div class="panel">
                                <div class="panel-heading">
                                        <h3 class="panel-title">Ubah Data Penelitian</h3>
                                </div>
                                <div class="panel-body">
                                <form action="/penelitian/create" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">No</label>
                                        <input name="id" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="No Terserah,Bisa Dikosongi">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Nomornya</small>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Judul</label>
                                        <input name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Judul">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Judulnya</small>
                                    </div>

                                    <div class="form-group">
                                    <label for="penelitian">Ketua</label>
                                        <select class="form-control" id="dosenk" name="dosene_id">
                                        <?php $__currentLoopData = $dosene; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ce->id); ?>"><?php echo e($ce->Nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                                <label for="exampleInputEmail1">Anggota</label>
                                                <div class="dropdown">
                                                    <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Pilih Yang Menjadi Anggota<b class="caret"></b></button></a>
                                                    <ul class="dropdown-menu">
                                                    <div style="OVERFLOW-Y:scroll; WIDTH:600px; HEIGHT:300px">
                                                    <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li id="dosen">
                                                        <input type="checkbox" name="dosen[]" id="dosen" value="<?php echo e($p->id); ?>">
                                                                <label>
                                                                <span><?php echo e($p->Nama); ?></span>
                                                                </label>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li id="mahasiswa">
                                                        <input type="checkbox" name="mahasiswa[]" id="mahasiswa" value="<?php echo e($yu->id); ?>">
                                                                <label value="<?php echo e($yu->id); ?>">
                                                                <span><?php echo e($yu->Nama); ?></span>
                                                                </label>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                    </ul>
                                                </div>
                                                <small id="emailHelp" class="form-text text-muted">Pilih Anggota</small>
                                                <br>
                                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#mahasiswaModal">
                                                        Tambah Mahasiswa
                                                </button>
                                                <br></br>
                                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#dosenModal">
                                                        Tambah Dosen
                                                </button>
                                    </div>
            
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Tahun</label>
                                        <input name="Tahun" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Tahun">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Tahun</small>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Laporan</label>
                                        <input name="Laporan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Laporan">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Laporan</small>
                                    </div>

                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Proposal</label>
                                        <input name="Proposal" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Proposal">
                                        <small id="emailHelp" class="form-text text-muted">Masukan Proposal</small>
                                    </div>  
                                    
                                    <div class="form-group">
                                    <label for="bidang">Bidang</label>
                                        <select class="form-control" id="bidang" name="bidang_id">
                                        <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ce->id); ?>"><?php echo e($ce->Nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                    <label for="kategori">Kategori</label>
                                        <select class="form-control" id="kategori" name="kategori_id">
                                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ke): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ke->id); ?>"><?php echo e($ke->Nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                        </form>
                            </div>


                                </div>        

                            </div>

                        </div>
                </div>
            </div>
        </div>
<?php echo $__env->make('campuran.dosen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('campuran.mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('auto'); ?>
<script>
$(document).ready(function(){
    $('#addmahasiswa').submit(function( event ) {
        event.preventDefault();
        $.ajax({
            url: '/mahasiswa/create',
            type: 'post',
            data: $('#addmahasiswa').serialize(), // Remember that you need to have your csrf token included
            dataType: 'json',
            success: function(success){
                console.log(success)
                $('#mahasiswaModal').modal('hide'),
                alert("Data Dah Di Save");             
            },
            error: function(error){
                console.log(error)
                alert("Data Tidak Ke Save");
            }
            })
            .done(function(res) {
            // make new option based on ajax response
            var input = '<li><input type="checkbox" name="mahasiswa[]" id="mahasiswa" value="'+ res.id +'"><label><span>' + res.Nama +'</span></label></li>';
            // append option to catogory select
            $('#mahasiswa').append(input);
            });
    });
    $('#submit').click,
    $('#adddosen').submit(function( event ) {
        event.preventDefault();
        $.ajax({
            url: '/dosen/create',
            type: 'post',
            data: $('#adddosen').serialize(), // Remember that you need to have your csrf token included
            dataType: 'json',
            success: function(success){
                console.log(success)
                $('#dosenModal').modal('hide'),
                alert("Data Dah Di Save");             
            },
            error: function(error){
                console.log(error)
                alert("Data Tidak Ke Save");
            }
            })
            .done(function(res) {
            // make new option based on ajax response
            var input = '<li><input type="checkbox" name="dosen[]" id="dosen" value="'+ res.id +'"><label><span>' + res.Nama +'</span></label></li>';
            var inputk='<option value="'+ res.id +'">'+ res.Nama +'</option>';
            // append option to catogory select
            $('#dosen').append(input);
            $('#dosenk').append(inputk);
            });
    });
    $('#submit').click
});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/perpustakaan/resources/views/penelitian/createpenelitian.blade.php ENDPATH**/ ?>