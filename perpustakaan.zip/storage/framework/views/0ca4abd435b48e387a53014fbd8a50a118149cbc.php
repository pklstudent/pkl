
<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
                            <?php if(session('sukses')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(session('sukses')); ?>

                                </div>
                            <?php endif; ?>
                <div class="row">
                <div class="col-md-12">
			<!-- TABLE HOVER -->
			<div class="panel">
				    <div class="panel-heading">
                        <h3 class="panel-title">Data Penulis</h3>
                        <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                        <div class="right">
                        <button type="button" class="btn" data-toggle="modal" data-target="#penulisModal"><a class="btn btn-success">Tambah Penulis</a></button>
                        </div>
                        <?php endif; ?>  
                    </div> 
				<div class="panel-body">
                <form action="/penulis" method="get">
                    <div class="input-group">
                                                <input class="form-control" name="cari" type="text" placeholder="Tulis Nama Penulisnya">
                                                <span  class="input-group-btn"><button class="btn btn-primary">Cari</button></span> 
                    </div>
                </form>
                <br>
					<table class="table table-hover">
						<thead>
							<tr>
                            <th>No</th>
                            <th>Nama Depan</th>
                            <th>Nama Belakang</th>
                            </tr>
						</thead>
						<tbody>
                        
                        <?php $__currentLoopData = $data_penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($pk->id); ?></td>
                            <td><?php echo e($pk->NamaDepan); ?></td>
                            <td><?php echo e($pk->NamaBelakang); ?></td>
                            <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                            <td><a href="/penulis/<?php echo e($pk->id); ?>/editpenulis" class="btn btn-warning btn-sm" >Ubah</a></td>
                            <td><a href="/penulis/<?php echo e($pk->id); ?>/hapus" class="btn btn-danger btn-sm" onclick="return confirm('Hapus nih ?')">Hapus</a></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
					</table>
                    <b>Halaman :</b>                   <span class="badge"><?php echo e($data_penulis->currentPage()); ?></span><br/>
                    <b> Jumlah Data :</b>              <span class="badge"> <?php echo e($data_penulis->total()); ?> </span><br/>
                    <b> Data Per Halaman : </b>         <span class="badge">  <?php echo e($data_penulis->perPage()); ?></span> <br/>
                
                
                    <?php echo e($data_penulis->links()); ?>

				</div>
			</div>
			<!-- END TABLE HOVER -->

		</div>

                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="penulisModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Inputkan Datanya</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                            <form action="/buku/penulisadd" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Kode Penulis</label>
                                <input name="id" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="No Penulis">
                                <small id="emailHelp" class="form-text text-muted">Masukan Kode Penulis</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="exampleInputEmail1">Nama Depan</label>
                                <input name="NamaDepan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama Depan">
                                <small id="emailHelp" class="form-text text-muted">Masukan Namanya</small>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Nama Belakang</label>
                                <input name="NamaBelakang" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nama Belakang">
                                <small id="emailHelp" class="form-text text-muted">Masukan Nama Belakangnya</small>
                            </div>
                                                        
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        </form>
                    </div>
                    </div>
                </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/perpustakaan/resources/views/penulis/index.blade.php ENDPATH**/ ?>