
                                        <label for="exampleInputEmail1">Penulis</label>
                                        <div class="dropdown">
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Daftar Penulis<b class="caret"></b></button></a>
                                            <ul class="dropdown-menu">
                                             <div style="OVERFLOW-Y:scroll; WIDTH:300px; HEIGHT:300px">    
                                                <?php $__currentLoopData = $penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <input type="checkbox" name="penulis[]" id="penulis" value="<?php echo e($p->id); ?>">
                                                            <label>
                                                                <span><?php echo e($p->NamaDepan); ?>

                                                                <?php echo e($p->NamaBelakang); ?></span>
                                                            </label>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             </div>
                                            </ul>
                                        </div>
                                        <small id="emailHelp" class="form-text text-muted">Pilih Penulis</small>
                                        
                        <?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/buku/penulis.blade.php ENDPATH**/ ?>