<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
                <div class="row">

                <div class="col-md-12">

			<!-- TABLE HOVER -->
			<div class="panel">
				    <div class="panel-heading">
                        <h3 class="panel-title">Data Pengabdian</h3>
                        <div class="right">
                        <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                        <button type="button" class="btn" data-toggle="modal" data-target="#exampleModal"><b class="btn btn-success">Tambah Pengabdian</b></button>
                        <?php endif; ?>
                        <div class="btn-group">
											<button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><b class="btn btn-default">Bidang
												<span class="caret"></b></span>
											</button>
											<ul class="dropdown-menu" role="menu">
                                            <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li><a href="<?php echo e(route('bidangpengabdian',$bi->id)); ?>"><?php echo e($bi->Nama); ?><span class="badge"><?php echo e($bi->pengabdian->count()); ?></span></a>
												</li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</ul>
						</div>
                        </div>  
                    </div> 
				<div class="panel-body">
                <form action="<?php echo e(url('pengabdian')); ?>" method="get">
                    <div class="input-group">
						<input class="form-control" name="cari" type="text" placeholder="Tulis Judulnya">
						<span  class="input-group-btn"><button class="btn btn-primary">Cari</button></span> 
                    </div>
                </form>
                <br>
					<table class="table table-hover">
						<thead>
							<tr>
                            <th>No</th>
                            <th>Judul</th>
                            <th>Tahun</th>
                            <th>Ketua</th>
                            <th>Anggota</th>
                            <th>Bidang</th>
                            <th>Kategori</th>
                            </tr>
						</thead>
						<tbody>
                        <?php $__currentLoopData = $data_pengabdian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pe->id); ?></td>
                            <td><a href="<?php echo e(url('pengabdian/'.$pe->id.'/detail')); ?>"><?php echo e($pe->Judul); ?></a></td>
                            <td><?php echo e($pe->Tahun); ?></td>
                            <td><a href="<?php echo e(url('pengabdian/'.$pe->Ketua['id'].'/detail')); ?>"><?php echo e($pe->Ketua['Nama']); ?></a></td>
                            <td><?php $__currentLoopData = $pe->dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul><li><a href="<?php echo e(url('dosen/'.$ce->id.'/detail')); ?>"><?php echo e($ce->Nama); ?></a></li></ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $pe->mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul><li><a href="<?php echo e(url('mahasiswa/'.$be->id.'/detail')); ?>"><?php echo e($be->Nama); ?></a></li></ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                            <td><?php echo e($pe->bidang['Nama']); ?></td>
                            <td><?php echo e($pe->kategori['Nama']); ?></td>
                            <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                            <td><a href="<?php echo e(url('pengabdian/'.$pe->id.'/editpengabdian')); ?>" class="btn btn-warning btn-sm" >Edit</a></td>
                            <td><a href="<?php echo e(url('pengabdian/hapus/'.$pe->id)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus nih ?')">Hapus</a></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
					</table>
                    <b>Halaman :</b>                   <span class="badge"><?php echo e($data_pengabdian->currentPage()); ?></span><br/>
                    <b> Jumlah Data :</b>              <span class="badge"> <?php echo e($data_pengabdian->total()); ?> </span><br/>
                    <b> Data Per Halaman : </b>         <span class="badge">  <?php echo e($data_pengabdian->perPage()); ?></span> <br/>
                
                
                    <?php echo e($data_pengabdian->links()); ?>

				</div>
			</div>
			<!-- END TABLE HOVER -->

		</div>

                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Inputkan Datanya</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                            <form action="<?php echo e(url('pengabdian/create')); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">No</label>
                                <input name="id" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Kode Penelitian">
                                <small id="emailHelp" class="form-text text-muted">Masukan No Terakhir</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="exampleInputEmail1">Judul</label>
                                <input name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Judul">
                                <small id="emailHelp" class="form-text text-muted">Masukan Judul</small>
                            </div>
       
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tahun</label>
                                <input name="Tahun" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Tahun">
                                <small id="emailHelp" class="form-text text-muted">Masukan Tahunnya</small>
                            </div>

                            <div class="form-group">
							<label for="pengabdian">Ketua</label>
								<select class="form-control" id="pengabdian" name="ketua_id">
								<?php $__currentLoopData = $ketua; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($ce->id); ?>"><?php echo e($ce->Nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            <div class="form-group">
                                        <label for="exampleInputEmail1">Anggota</label>
                                        <div class="dropdown">
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Pilih Yang Menjadi Anggota<b class="caret"></b></button></a>
                                            <ul class="dropdown-menu">
                                            <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <div class="checkbox">
                                                    <?php echo e(Form::checkbox('dosen[]', $p->id)); ?>

                                                        <label value="<?php echo e($p->id); ?>">
                                                        <span><?php echo e($p->Nama); ?></span>
                                                        </label>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <div class="checkbox">
                                                    <?php echo e(Form::checkbox('mahasiswa[]', $yu->id)); ?>

                                                        <label value="<?php echo e($yu->id); ?>">
                                                        <span><?php echo e($yu->Nama); ?></span>
                                                        </label>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <small id="emailHelp" class="form-text text-muted">Pilih Penulis</small>
                            </div>

                            <div class="form-group">
							<label for="penulis">Kategori</label>
								<select class="form-control" id="kategori" name="kategori_id">
								<?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($be->id); ?>"> <?php echo e($be->Nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            <div class="form-group">
							<label for="penulis">Bidang</label>
								<select class="form-control" id="bidang" name="bidang_id">
								<?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($ce->id); ?>"><?php echo e($ce->Nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            
                            
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        </form>
                    </div>
                    </div>
                </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/pengabdian/index.blade.php ENDPATH**/ ?>