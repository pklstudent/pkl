<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
							<?php if(session('success')): ?>
                            <div class="alert alert-succes" role="alert">
                             <?php echo e(session('success')); ?>

                            </div>
                            <?php endif; ?>

							<?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                             <?php echo e(session('error')); ?>

                            </div>
                            <?php endif; ?>
                <div class="row">

                <div class="col-md-12">
							<!-- PANEL NO PADDING -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Panel</h3>
									<div class="right">
									</div>
								</div>
								<div class="panel-body no-padding bg-primary text-center">
									<div class="padding-top-30 padding-bottom-30">
										<i class="fa fa-thumbs-o-up fa-5x"></i>
										<h3>No Content Padding</h3>
									</div>
								</div>
							</div>
							<!-- END PANEL NO PADDING -->


							<div class="col-md-12">

							<!-- CONDENSED TABLE -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Tabel Skripsi</h3>
									<div class="right">
                  <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
									<button type="button" data-toggle="modal" data-target="#exampleModalLong">
                  <a class="btn btn-info" href="#">
                  <i class="glyphicon glyphicon-ok-circle"></i>
                    Validasikan
                  </a>
                  </button>
                  <?php endif; ?>
									</div>
								</div>
								<div class="panel-body">
									<table class="table table-condensed">
                                    <thead>
							<tr>
                            <th>No</th>
                            <th>Judul</th>
                            <th>Tahun</th>
                            <th>File</th>
                            <th>Mahasiswa</th>
                            <th>Pembimbing Satu</th>
                            <th>Pembimbing Dua</th>
                            <th>Bidang</th>
                            <th>Verifikasi</th>
                            <th>Upload</th>
                            <th>Prosesing</th>
                            </tr>
						</thead>
						<tbody>
                        <tr>
                            <td><?php echo e($skripsi->id); ?></td>
                            <td><?php echo e($skripsi->Judul); ?></td>
                            <td><?php echo e($skripsi->Tahun); ?></td>
                            <td><?php echo e($skripsi->File); ?></td>
                            <td><?php echo e($skripsi->mahasiswa['Nama']); ?></td>
                            <td><?php echo e($skripsi->pembimbing1['Nama']); ?></td>
                            <td><?php echo e($skripsi->pembimbing2['Nama']); ?></td>
                            <td><?php echo e($skripsi->bidang['Nama']); ?></td>
                            <td><?php echo e($skripsi->verifikasi['Nama']); ?></td>
                            <td><?php echo e($skripsi->created_at); ?></td>
                            <td><?php echo e($skripsi->updated_at); ?></td>
                            </tr>
                        </tbody>
									</table>
								</div>
							</div>
							<!-- END CONDENSED TABLE -->

		</div>
					

			</div>
        </div>
    </div>
</div>


<!-- Modal -->


    <!-- Modal -->
    <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Verifikasi Skripsi</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <form action="<?php echo e(url('skripsi/'.$skripsi->id.'/goverifikasi')); ?>" method="post">
      <div class="modal-body">
              <div class="form-group">
              <?php echo e(csrf_field()); ?>

                                <label for="skripsi">Verifikasi</label>
                                    <select class="form-control" id="skripsi" name="verifikasi_id">
                                    <?php $__currentLoopData = $verifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $we): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($we->id); ?>"><?php echo e($we->Nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
              </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Keluar</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/skripsi/detail.blade.php ENDPATH**/ ?>