<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
                        <?php if(session('sukses')): ?>
                            <div class="alert alert-success" role="alert">
                             <?php echo e(session('sukses')); ?>

                            </div>
                        <?php endif; ?>

							<?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                             <?php echo e(session('error')); ?>

                            </div>
                            <?php endif; ?>
                <div class="row">

                <div class="col-md-12">

			<!-- TABLE HOVER -->
			<div class="panel">
				    <div class="panel-heading">
                        <h3 class="panel-title">Data Penelitian</h3>
                        <div class="right">
                        <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                        <button type="button"><a href="<?php echo e(url('penelitian/createpenelitian')); ?>" class="btn btn-success">Tambah Data Penelitian</a></button>
                        <?php endif; ?>
                        <div class="btn-group">
											<button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><a class="btn btn-default">Bidang
												<span class="caret"></span></a>
											</button>
											<ul class="dropdown-menu" role="menu">
                                            <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li><a href="<?php echo e(route('bidangpenelitian',$bi->id)); ?>"><?php echo e($bi->Nama); ?>

												<span class="badge badge-pull-left"><?php echo e($bi->penelitian->count()); ?></span></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</ul>
						</div>
                        </div>
                    </div> 
				<div class="panel-body">
                <form action="<?php echo e(url('penelitian')); ?>" method="get">
                    <div class="input-group">
                                                <input class="form-control" name="cari" type="text" placeholder="Tulis Judul">
                                                <span  class="input-group-btn"><button class="btn btn-primary">Cari</button></span> 
                    </div>
                </form>
                <br>
					<table class="table table-hover">
						<thead>
							<tr>
                            <th>No</th>
                            <th>Judul</th>
                            <th>Tahun</th>
                            <th>Ketua</th>
                            <th>Anggota</th>
                            <th>Bidang</th>
                            <th>Kategori</th>
                            <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                            <th>Pilihan</th>
                            <?php endif; ?>
                            </tr>
						</thead>
						<tbody>
                        
                        <?php $__currentLoopData = $data_penelitian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pe->id); ?></td>
                            <td><a href="<?php echo e(url('penelitian/'.$pe->id.'/detail')); ?>"><?php echo e($pe->Judul); ?></a></td>
                            
                            <td><?php echo e($pe->Tahun); ?></td>
                            <td><a href="<?php echo e(url('dosen/'.$pe->dosene['id'].'/detail')); ?>"><?php echo e($pe->dosene['Nama']); ?></a>
                            </td>
                            <td><?php $__currentLoopData = $pe->dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul><li><a href="<?php echo e(url('dosen/'.$ce->id.'/detail')); ?>"><?php echo e($ce->Nama); ?></a></li></ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $pe->mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul><li><?php echo e($be->Nama); ?></li></ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($pe->bidang['Nama']); ?></td>
                            <td><?php echo e($pe->kategori['Nama']); ?></td>
                            <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                            <td><a href="<?php echo e(url('penelitian/'.$pe->id.'/editpenelitian')); ?>" class="btn btn-warning btn-sm" >Ubah</a></td>
                            <td><a href="<?php echo e(url('penelitian/hapus/'.$pe->id)); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus nih ?')">Hapus</a></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
					</table>
                    <b>Halaman :</b>                   <span class="badge"><?php echo e($data_penelitian->currentPage()); ?></span><br/>
                    <b> Jumlah Data :</b>              <span class="badge"> <?php echo e($data_penelitian->total()); ?> </span><br/>
                    <b> Data Per Halaman : </b>         <span class="badge">  <?php echo e($data_penelitian->perPage()); ?></span> <br/>
                
                
                    <?php echo e($data_penelitian->links()); ?>

				</div>
			</div>
			<!-- END TABLE HOVER -->

		</div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/perpustakaan/resources/views/penelitian/index.blade.php ENDPATH**/ ?>