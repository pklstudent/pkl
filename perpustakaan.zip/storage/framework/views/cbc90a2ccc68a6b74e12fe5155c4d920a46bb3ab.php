<?php $__env->startSection('content'); ?>
<div class="main">
    <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <!--tabel input-->
                        <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Ubah</h3>
                            
                            <?php if(session('sukses')): ?>
                            <div class="alert alert-succes" role="alert">
                             <?php echo e(session('sukses')); ?>

                            </div>
                            <?php endif; ?>
                            
                        </div>
                        <div class="panel-body">
                            <!--ubah nya gan-->
                            
                <form action="/pengabdian/update" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                                <label for="exampleInputEmail1">No</label>
                                <input required="required" name="id" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($pengabdian->id); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan No Terakhir</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="exampleInputEmail1">Judul</label>
                                <input required="required" name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($pengabdian->Judul); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Judul</small>
                            </div>
       
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tahun</label>
                                <input name="Tahun" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($pengabdian->Tahun); ?>">
                                <small id="emailHelp" class="form-text text-muted">Masukan Penerbit Buku</small>
                            </div>

                            <div class="form-group">
							<label for="penulis">Dosen</label>
								<select class="form-control" id="dosen" name="dosen_id">
								<?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($a->id); ?>"> <?php echo e($a->Nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            <div class="form-group">
							<label for="penulis">Kategori</label>
								<select class="form-control" id="kategori" name="kategori_id">
								<?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $be): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($be->id); ?>"> <?php echo e($be->Nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>

                            <div class="form-group">
							<label for="penulis">Bidang</label>
								<select class="form-control" id="bidang" name="bidang_id">
								<?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($ce->id); ?>"><?php echo e($ce->Nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                            </div>
                    <div class="modal-footer">
                    <input type="submit" value="Simpan" class="btn btn-dark">   
                
                </form>
            
                        </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
   

<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/pengabdian/ubah.blade.php ENDPATH**/ ?>