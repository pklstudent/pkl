<?php $__env->startSection('content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<div class="main-content">
            <div class="container-fluid">
							<?php if(session('sukses')): ?>
                            <div class="alert alert-succes" role="alert">
                             <?php echo e(session('sukses')); ?>

                            </div>
                            <?php endif; ?>

							<?php if(session('error')): ?>
                            <div class="alert alert-danger" role="alert">
                             <?php echo e(session('error')); ?>

                            </div>
                            <?php endif; ?>
                <div class="row">

                        <div class="col-md-12">

                            <div class="panel">
                                    <div class="panel-heading">
                                            <h3 class="panel-title">Ubah Data PKL dan KKM</h3>
                                    </div>  
                                <div class="panel-body">
                                <!--form-->
                <form action="/pklkkm/create" method="POST" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Kode PKL dan KKM</label>
                                <input name="id" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Silahkan jika ingin dikosongi">
                                <small id="emailHelp" class="form-text text-muted">Masukan Kode Pkl dan KKM</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="exampleInputEmail1">Judul</label>
                                <input name="Judul" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Judul">
                                <small id="emailHelp" class="form-text text-muted">Masukan Judulnya</small>
                            </div>

                            <div class="form-group">
							<label for="pklkkm">Pembimbing</label>
								<select class="form-control" id="dosen" name="KodeDosen">
								<?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($p->id); ?>"><?php echo e($p->Nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#dosenModal">
                                                        Tambah Dosen
                                                </button>
                            </div>

                            <div class="form-group">
                                        <label for="exampleInputEmail1">Anggota Mahasiswa</label>
                                        <div class="dropdown">
                                            <a href="#" data-toggle="dropdown" class="dropdown-toggle"><button>Pilih Anggotanya<b class="caret"></b></button></a>
                                            <ul class="dropdown-menu">
                                            <div style="OVERFLOW-Y:scroll; WIDTH:300px; HEIGHT:300px">
                                            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li id="mahasiswa">
                                                <input type="checkbox" name="mahasiswa[]" id="mahasiswa" value="<?php echo e($yu->id); ?>">
                                                        <label>
                                                        <span><?php echo e($yu->Nama); ?></span>
                                                        </label>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            </ul>
                                        </div>
                                        <small id="emailHelp" class="form-text text-muted">Pilih Anggota</small><br>
                                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#mahasiswaModal">
                                                        Tambah Mahasiswa
                                                </button>
                            </div>
       
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tahun</label>
                                <input name="Tahun" type="int" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Tahun">
                                <small id="emailHelp" class="form-text text-muted">Masukan Tahun</small>
                            </div>

                            <div class="form-group">
							<label for="pklkkm">Mitra</label>
								<select class="form-control" id="mitra" name="IDMitra">
								<?php $__currentLoopData = $mitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($cer->id); ?>"><?php echo e($cer->Nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
                                <small id="emailHelp" class="form-text text-muted">Pilih Mitra</small>
                            </div>
                            <br>
                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#mitraModal">
                                    Tambah Mitra
                            </button>

                            <div class="form-group">
                                                        <label for="File">File</label>
                                                        <input name="File" type="file" class="form-control" accept="application/pdf" />
                                                        <small id="emailHelp" class="form-text text-muted">Masukan Filenya</small>
                            </div>
                     
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
                                <!---->
                                </div>
                            </div>
                        </div>
                </div>
            </div>
</div>
<?php echo $__env->make('campuran.mitra', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('campuran.mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('campuran.dosen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('auto'); ?>
<script>
$(document).ready(function(){
    $('#addmahasiswa').submit(function( event ) {
        event.preventDefault();
        $.ajax({
            url: '/mahasiswa/create',
            type: 'post',
            data: $('#addmahasiswa').serialize(), // Remember that you need to have your csrf token included
            dataType: 'json',
            success: function(success){
                console.log(success)
                $('#mahasiswaModal').modal('hide'),
                alert("Data Dah Di Save");             
            },
            error: function(error){
                console.log(error)
                alert("Data Tidak Ke Save");
            }
            })
            .done(function(res) {
            // make new option based on ajax response
            var input = '<li><input type="checkbox" name="mahasiswa[]" id="mahasiswa" value="'+ res.id +'"><label><span>' + res.Nama +'</span></label></li>';
            // append option to catogory select
            $('#mahasiswa').append(input);
            });
    });
    $('#submit').click,
    $('#adddosen').submit(function( event ) {
        event.preventDefault();
        $.ajax({
            url: '/dosen/create',
            enctype:'multipart/form-data',
            type: 'post',
            data: $('#adddosen').serialize(), // Remember that you need to have your csrf token included
            dataType: 'json',
            success: function(success){
                console.log(success)
                $('#dosenModal').modal('hide'),
                alert("Data Dah Di Save");             
            },
            error: function(error){
                console.log(error)
                alert("Data Tidak Ke Save");
            }
            })
            .done(function(res) {
            // make new option based on ajax response
            var input='<option value="'+ res.id +'">'+ res.Nama +'</option>';
            // append option to catogory select
            $('#dosen').append(input);
            });
    });
    $('#submit').click,
    $('#addmitra').submit(function( event ) {
        event.preventDefault();
        $.ajax({
            url: '/pklkkm/mitracreate',
            type: 'post',
            data: $('#addmitra').serialize(), // Remember that you need to have your csrf token included
            dataType: 'json',
            success: function(success){
                console.log(success)
                $('#mitraModal').modal('hide'),
                alert("Data Dah Di Save");             
            },
            error: function(error){
                console.log(error)
                alert("Data Tidak Ke Save");
            }
            })
            .done(function(res) {
            // make new option based on ajax response
            var input='<option value="'+ res.id +'">'+ res.Nama +'</option>';
            // append option to catogory select
            $('#mitra').append(input);
            });
    });
    $('#submit').click
});
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/pklkkm/createpklkkm.blade.php ENDPATH**/ ?>