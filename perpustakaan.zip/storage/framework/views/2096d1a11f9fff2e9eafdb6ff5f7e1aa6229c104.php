<?php $__env->startSection('content'); ?>
        <div class="main-content">
            <div class="container-fluid">
                            <?php if(session('sukses')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(session('sukses')); ?>

                                </div>
                            <?php endif; ?>
                <div class="row">
                <div class="col-md-12">
			<!-- TABLE HOVER -->
			<div class="panel">
				    <div class="panel-heading">
                        <h2 class="panel-title"><b> Data Buku</b></h2>
                        <div class="right">
                        <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                        <button type="button" class="btn btn-warning btn-sm" ><a class="btn btn-warning" href="<?php echo e(url('buku/createbuku')); ?>">Tambah Buku</a></button>
                        <?php endif; ?>
                        <div class="btn-group">
											<button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><b class="btn btn-danger">Penulis
												<span class="caret"></b></span>
											</button>
											<ul class="dropdown-menu" role="menu">
                                            <div style="OVERFLOW-Y:scroll; WIDTH:200px; HEIGHT:200px"> 
                                                <?php $__currentLoopData = $penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><a href="<?php echo e(route('penulisbuku',$ci->id)); ?>"><?php echo e($ci->NamaDepan); ?> <?php echo e($ci->NamaBelakang); ?></a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
											</ul>
						</div>
                        <div class="btn-group">
											<button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><b class="btn btn-default">Bidang
												<span class="caret"></b></span>
											</button>
											<ul class="dropdown-menu" role="menu">
                                            <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<li><a href="<?php echo e(route('bidangbuku',$bi->id)); ?>"><?php echo e($bi->Nama); ?></a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</ul>
						</div>
                        </div>  
                    </div> 
				<div class="panel-body">
                <form action="<?php echo e(url('buku')); ?>" method="get">
                    <div class="input-group">
                                                <input class="form-control" id="search" name="search" type="text" placeholder="Tulis Judulnya">
                                                <span  class="input-group-btn"><button class="btn btn-primary">Cari</button></span> 
                    </div>
                </form>

                <br>
					<table class="table table-hover">
						<thead>
							<tr>
                            <th>No</th>
                            <th>Gambar</th>
                            <th>
								<center>Info Buku</center>
                            </th>
                            <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                            <th><div class="center">Opsi</div></th>
                            <?php endif; ?> 
                            </tr>
						</thead>
						<tbody>
                        
                        <?php $__currentLoopData = $data_buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($buku->id); ?></td>
                        <td><img src="<?php echo e($buku->getFoto()); ?>" class="img-square" alt="Avatar" width="100px" height="100px"></td>
                            <td>
                            <div class="profile-detail">
										<ul class="list-unstyled">
                                        <li><span class="col-md-2">Penulis </span><ul class="col-md-10">: <?php $__currentLoopData = $buku->penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('penulisbuku',$p->id)); ?>"> <?php echo e($p->NamaBelakang); ?>,
                                         <?php echo e($p->NamaDepan); ?></a> | <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
                                        </li><hr>
                                            <li><span class="col-md-2">Judul </span><span class="col-md-10">: <a href="<?php echo e(url('buku/'.$buku->id.'/detail')); ?>"><?php echo e($buku->Judul); ?></a></span></li><hr>  
											<li><span class="col-md-2">Penerbit</span><span class="col-md-10">: <?php echo e($buku->Penerbit); ?></span></li><hr>
											<li><span class="col-md-2">Tahun</span><span class="col-md-10">: <?php echo e($buku->Tahun); ?></span></li><hr>
											<li><span class="col-md-2">Lokasi</span><span class="col-md-10">: <?php echo e($buku->lokasi['NamaLokasi']); ?></span></li><hr>
											<li><span class="col-md-2">Bidang </span><ul class="col-md-10">: <?php $__currentLoopData = $buku->bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(route('bidangbuku',$h->id)); ?>"><?php echo e($h->Nama); ?></a> | <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></li>
                                        </li>
										</ul>
                            </div>
                            </td>   
                            <?php if(Auth::check() && Auth::user()->role =='admin'): ?>
                            <td><a href="<?php echo e(url('buku/'.$buku->id.'/editbuku')); ?>" class="btn btn-warning btn-sm" >Ubah</a>
                            </p>
                            <a href="<?php echo e(url('buku/'.$buku->id.'/hapus')); ?>" class="btn btn-danger btn-sm" enctype="multipart/form-data" onclick="return confirm('Hapus nih ?')">Hapus</a></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
					</table>
                            <b>Halaman :</b>                   <span class="badge"><?php echo e($data_buku->currentPage()); ?></span><br/>
                            <b> Jumlah Data :</b>              <span class="badge"> <?php echo e($data_buku->total()); ?> </span><br/>
                            <b> Data Per Halaman : </b>         <span class="badge">  <?php echo e($data_buku->perPage()); ?></span> <br/>
                                
                            
                    <p align="right">
                        <?php echo e($data_buku->links()); ?>

                    </p>
                    <div class="input-group mb-3">
				</div>
			</div>
			<!-- END TABLE HOVER -->
		        </div>
            <!--Sidebar-->
            <!--ooo-->
                </div>
            </div>
        </div>

    <?php $__env->startSection('auto'); ?>
    <script src="<?php echo e(asset('public/js/1124.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/ui1121.js')); ?>"></script>
    <script>
    $(document).ready(function() {
        $( "#search" ).autocomplete({

            source: function(request, response) {
                $.ajax({
                url: "<?php echo e(url('autocompletebuku')); ?>",
                data: {
                        term : request.term
                },
                dataType: "json",
                success: function(data){
                var resp = $.map(data,function(obj){
                        //console.log(obj.city_name);
                        return obj.Judul;
                }); 

                response(resp);
                }
            });
        },
        minLength: 1
        });
    });
    </script>
    <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('tampilan.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\perpustakaan\resources\views/buku/index.blade.php ENDPATH**/ ?>